Shiny Dashboard Example
=======================

By Thomas Reinholdsson

[http://glimmer.rstudio.com/reinholdsson/shiny-dashboard/](http://glimmer.rstudio.com/reinholdsson/shiny-dashboard/)

## Dependencies

- [Shiny](http://www.rstudio.com/shiny/)
- [data.table](http://datatable.r-forge.r-project.org/)
- [rHighcharts](https://github.com/metagraf/rHighcharts)
- [Coldbir](https://github.com/SthlmR/Coldbir)
- [lubridate](http://cran.r-project.org/web/packages/lubridate/index.html)
- [hwriter](http://cran.r-project.org/web/packages/hwriter/index.html)
- [zoo](http://cran.r-project.org/web/packages/zoo/index.html)
