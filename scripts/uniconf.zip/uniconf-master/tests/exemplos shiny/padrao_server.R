library(shiny)
shinyServer(function(input, output) 
{
  # Aqui pode ir alguma fun�ao que faz allguma coisa.
})