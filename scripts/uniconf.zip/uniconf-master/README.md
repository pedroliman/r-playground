﻿uniconf
=======

Projeto que tem o objetivo de permitir o aprendizado da plataforma R e sua interação com bancos de dados.
Faremos isto construindo um projeto real de análise quantitativa de confiabilidade que permite ao usuário, a partir de seus dados de falha estimar a sua confiabilidade em um determinado intervalo de tempo, ou vice versa.
